﻿using System.ComponentModel.DataAnnotations;

namespace ChocoLync.Models
{
    public class Department : BaseEntity
    {
        [Required(ErrorMessage = "Department Name is required.")]
        [StringLength(50)]
        public string Name { get; set; }

        [StringLength(200)]
        public string? Description { get; set; }
    }
}