namespace ChocoLync.Models
{
    public class SaleReportViewModel
    {
        public string Period { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public List<SaleReportItem> Sales { get; set; } = new();
        public decimal TotalAmount { get; set; }
        public int TotalQuantity { get; set; }
        public decimal TotalProfit { get; set; }
        public int TotalSalesCount => Sales.Count;
    }

    public class SaleReportItem
    {
        public DateTime Date { get; set; }
        public string Product { get; set; }
        public string Customer { get; set; }
        public string Employee { get; set; }
        public int Quantity { get; set; }
        public decimal TotalAmount { get; set; }
        public decimal Profit { get; set; }
    }
}
