﻿namespace ChocoLync.Models
{
    public class CheckoutViewModel
    {
        public string? CustomerName { get; set; }

        public string? CustomerPhone { get; set; }

        public string? CustomerAddress { get; set; }

        public List<CartItem>? CartItems { get; set; }
    }
}