﻿using System.ComponentModel.DataAnnotations.Schema;

namespace ChocoLync.Models
{
    public class OrderItem : BaseEntity
    {
        public int OrderId { get; set; }

        public Order? Order { get; set; }

        public int ProductId { get; set; }

        public Product? Product { get; set; }

        public int Quantity { get; set; }

        [Column(TypeName = "decimal(18,2)")]
        public decimal Price { get; set; }
    }
}