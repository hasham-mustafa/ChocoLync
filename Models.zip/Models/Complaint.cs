using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ChocoLync.Models
{
    public class Complaint : BaseEntity
    {
        [Required]
        [StringLength(100)]
        public string CustomerName { get; set; }

        [Required]
        [Phone]
        public string CustomerPhone { get; set; }

        public int? CustomerId { get; set; }

        [ForeignKey("CustomerId")]
        public Customer? Customer { get; set; }

        [Required]
        public string Description { get; set; }

        public DateTime ComplaintDate { get; set; }

        [StringLength(50)]
        public string Status { get; set; } = "Pending";

        [StringLength(100)]
        public string? CurrentHandler { get; set; }

        public string? AdminResponse { get; set; }

        public DateTime? ResolvedDate { get; set; }
    }
}
