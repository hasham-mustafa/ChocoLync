﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ChocoLync.Models
{
    public class Purchase : BaseEntity
    {
        [Required]
        public DateTime PurchaseDate { get; set; }

        [Required]
        public string SupplierName { get; set; }

        [Required]
        public int QuantityBought { get; set; }

        [Required]
        [Column(TypeName = "decimal(18,2)")]
        public decimal TotalCost { get; set; }

        [Required]
        public int ProductId { get; set; }

        [ForeignKey("ProductId")]
        public Product? Product { get; set; }
    }
}