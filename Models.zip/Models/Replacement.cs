using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ChocoLync.Models
{
    public class Replacement : BaseEntity
    {
        [Required]
        public int OrderId { get; set; }
        [ForeignKey("OrderId")]
        public Order? Order { get; set; }

        [Required]
        public int OriginalProductId { get; set; }
        [ForeignKey("OriginalProductId")]
        public Product? OriginalProduct { get; set; }

        [Required]
        public int ReplacementProductId { get; set; }
        [ForeignKey("ReplacementProductId")]
        public Product? ReplacementProduct { get; set; }

        [Required]
        public int Quantity { get; set; }

        [StringLength(500)]
        public string? Reason { get; set; }

        public DateTime ReplacementDate { get; set; }

        [Required]
        [StringLength(20)]
        public string Status { get; set; } = "Pending";
    }
}
