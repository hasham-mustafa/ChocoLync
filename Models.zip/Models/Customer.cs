﻿using System.ComponentModel.DataAnnotations;

namespace ChocoLync.Models
{
    public class Customer : BaseEntity
    {
        [Required]
        public string Name { get; set; }

        [Required]
        public string Username { get; set; }

        [Required]
        public string Password { get; set; }

        // NEW FIELDS

        public string? Email { get; set; }

        public string? Phone { get; set; }

        public string? Country { get; set; }

        public string? CNIC { get; set; }

        public DateTime? DateOfBirth { get; set; }

        public string? Address { get; set; }

        public string? ProfileImage { get; set; }

        public int LoyaltyPoints { get; set; } = 0;
    }
}