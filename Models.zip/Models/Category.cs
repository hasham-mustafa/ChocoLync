﻿using System.ComponentModel.DataAnnotations;

namespace ChocoLync.Models
{
    public class Category : BaseEntity
    {
        [Required]
        [StringLength(50)]
        public string Name { get; set; }
    }
}