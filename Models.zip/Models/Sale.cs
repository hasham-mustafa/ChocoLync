﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ChocoLync.Models
{
    public class Sale : BaseEntity
    {
        [Required]
        public DateTime SaleDate { get; set; }

        [Required]
        public int QuantitySold { get; set; }

        [Column(TypeName = "decimal(18,2)")]
        public decimal Profit { get; set; }
        [Required]
        [Column(TypeName = "decimal(18,2)")]
        public decimal TotalAmount { get; set; }

        [Required]
        public int ProductId { get; set; }
        [ForeignKey("ProductId")]
        public Product? Product { get; set; }

        public int? CustomerId { get; set; }
        [ForeignKey("CustomerId")]
        public Customer? Customer { get; set; }

        public int? EmployeeId { get; set; }
        [ForeignKey("EmployeeId")]
        public Employee? Employee { get; set; }

        public int Quantity { get; set; }

        public int? OrderId { get; set; }

        public bool IsReplacement { get; set; }
    }
}
