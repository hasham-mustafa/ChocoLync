namespace ChocoLync.Models
{
    public class ExpenseReportViewModel
    {
        public string Period { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public List<ExpenseReportItem> Expenses { get; set; } = new();
        public decimal TotalExpenses { get; set; }
        public decimal PeriodSalesTotal { get; set; }
        public decimal NetEarning => PeriodSalesTotal - TotalExpenses;
    }

    public class ExpenseReportItem
    {
        public DateTime Date { get; set; }
        public string Title { get; set; }
        public decimal Amount { get; set; }
        public string Description { get; set; }
    }
}
