﻿using System;
using System.ComponentModel.DataAnnotations;

namespace ChocoLync.Models
{
    public class BaseEntity
    {
        [Key]
        public int Id { get; set; }

        public DateTime CreatedDate { get; set; }

        public string? CreatedBy { get; set; }

        public bool IsActive { get; set; }

        public BaseEntity()
        {
            CreatedDate = DateTime.Now;
            IsActive = true;
        }
    }
}