﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ChocoLync.Models
{
    public class Employee : BaseEntity
    {
        [Required]
        [StringLength(100)]
        public string Name { get; set; }

        [Required]
        [Phone]
        public string Phone { get; set; }

        [EmailAddress]
        public string? Email { get; set; }

        public string? Country { get; set; }

        public string? CNIC { get; set; }

        public DateTime? DateOfBirth { get; set; }

        public string? Education { get; set; }

        public string? Address { get; set; }

        public string? ProfileImage { get; set; }

        [Required]
        public string Designation { get; set; }

        [Required]
        [Column(TypeName = "decimal(18,2)")]
        public decimal Salary { get; set; }

        [Required]
        public int DepartmentId { get; set; }

        [ForeignKey("DepartmentId")]
        public Department? Department { get; set; }
    }
}