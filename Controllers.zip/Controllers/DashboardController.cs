﻿using ChocoLync.Data;
using ChocoLync.Filters;
using ChocoLync.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ChocoLync.Controllers
{
    public class DashboardController : Controller
    {
        private readonly ApplicationDbContext _context;

        public DashboardController(ApplicationDbContext context)
        {
            _context = context;
        }

        [RoleAuthorize("Owner,Admin")]
        public IActionResult Index()
        {
            var role = HttpContext.Session.GetString("Role");

            ViewBag.TotalProducts = _context.Products.Count();
            ViewBag.TotalCustomers = _context.Customers.Count();
            ViewBag.TotalEmployees = _context.Employees.Count();
            ViewBag.TotalCategories = _context.Categories.Count();
            ViewBag.TotalDepartments = _context.Departments.Count();
            ViewBag.TotalPurchases = _context.Purchases.Count();
            ViewBag.TotalUsers = _context.Users.Count();
            ViewBag.TotalRoles = _context.Roles.Count();

            // Only count actual completed sales (not replacements, not from cancelled orders)
            var completedOrderIds = _context.Orders
                .Where(o => o.Status == "Completed")
                .Select(o => o.Id);

            var validSales = _context.Sales
                .Where(s => !s.IsReplacement && completedOrderIds.Contains(s.OrderId ?? 0));

            ViewBag.TotalSales = validSales.Count();
            ViewBag.TotalRevenue = validSales.Sum(s => (decimal?)s.TotalAmount) ?? 0;
            ViewBag.TotalProfit = validSales.Sum(s => (decimal?)s.Profit) ?? 0;

            // Expense filtering: Owner only sees expenses created by Admin
            IQueryable<Expense> expensesQuery;

            if (role == "Owner")
            {
                var adminUsernames = _context.Users
                    .Include(u => u.Role)
                    .Where(u => u.Role.Name == "Admin")
                    .Select(u => u.Username)
                    .ToList();

                expensesQuery = _context.Expenses
                    .Where(e => e.CreatedBy != null && adminUsernames.Contains(e.CreatedBy));
            }
            else
            {
                expensesQuery = _context.Expenses;
            }

            ViewBag.TotalExpenses = expensesQuery.Count();
            ViewBag.TotalExpenseAmount = expensesQuery.Sum(e => (decimal?)e.Amount) ?? 0;

            ViewBag.LowStockProducts = _context.Products
                .Count(p => p.StockQuantity <= p.AlertQuantity);

            ViewBag.RecentSales = validSales
                .Include(s => s.Product)
                .OrderByDescending(s => s.SaleDate).Take(5).ToList();

            var salesAnalytics = validSales
                .ToList()
                .GroupBy(s => new { s.SaleDate.Year, s.SaleDate.Month })
                .Select(g => new
                {
                    SortKey = g.Key.Year * 100 + g.Key.Month,
                    MonthName = System.Globalization.CultureInfo
                        .CurrentCulture
                        .DateTimeFormat
                        .GetAbbreviatedMonthName(g.Key.Month) + " " + g.Key.Year,
                    Total = g.Sum(x => x.TotalAmount)
                })
                .OrderBy(x => x.SortKey)
                .ToList();

            ViewBag.SalesLabels = salesAnalytics.Select(x => x.MonthName).ToList();
            ViewBag.SalesData = salesAnalytics.Select(x => x.Total).ToList();

            var expenseAnalytics = expensesQuery
                .ToList()
                .GroupBy(e => new { e.ExpenseDate.Year, e.ExpenseDate.Month })
                .Select(g => new
                {
                    SortKey = g.Key.Year * 100 + g.Key.Month,
                    MonthName = System.Globalization.CultureInfo
                        .CurrentCulture
                        .DateTimeFormat
                        .GetAbbreviatedMonthName(g.Key.Month) + " " + g.Key.Year,
                    Total = g.Sum(x => x.Amount)
                })
                .OrderBy(x => x.SortKey)
                .ToList();

            ViewBag.ExpenseLabels = expenseAnalytics.Select(x => x.MonthName).ToList();
            ViewBag.ExpenseData = expenseAnalytics.Select(x => x.Total).ToList();

            return View();
        }

        [RoleAuthorize("Employee")]
        public IActionResult EmployeeDashboard()
        {
            ViewBag.TotalOrders = _context.Orders.Count(o => o.Status != "Cancelled");
            ViewBag.TotalProducts = _context.Products.Count();
            ViewBag.LowStockProducts = _context.Products
                .Count(x => x.StockQuantity <= x.AlertQuantity);

            var monthlySales = _context.Orders
                .Where(o => o.Status != "Cancelled")
                .GroupBy(x => x.OrderDate.Month)
                .Select(g => new
                {
                    Month = g.Key,
                    Total = g.Sum(x => x.TotalAmount)
                })
                .OrderBy(x => x.Month)
                .ToList();

            ViewBag.Months = monthlySales
                .Select(x => System.Globalization.CultureInfo
                    .CurrentCulture
                    .DateTimeFormat
                    .GetMonthName(x.Month))
                .ToList();

            ViewBag.Sales = monthlySales.Select(x => x.Total).ToList();

            var topProducts = _context.OrderItems
                .Include(x => x.Product)
                .GroupBy(x => x.Product.Name)
                .Select(g => new
                {
                    Product = g.Key,
                    Quantity = g.Sum(x => x.Quantity)
                })
                .OrderByDescending(x => x.Quantity)
                .Take(5)
                .ToList();

            ViewBag.TopProducts = topProducts.Select(x => x.Product).ToList();
            ViewBag.TopQuantities = topProducts.Select(x => x.Quantity).ToList();

            ViewBag.RecentOrders = _context.Orders
                .OrderByDescending(x => x.OrderDate)
                .Take(5)
                .ToList();

            return View();
        }

        [RoleAuthorize("Customer")]
        public IActionResult CustomerDashboard()
        {
            ViewBag.TotalOrders = _context.Orders.Count(o => o.Status != "Cancelled");
            ViewBag.TotalProducts = _context.Products.Count();

            return View();
        }
    }
}
