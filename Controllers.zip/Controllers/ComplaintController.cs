using ChocoLync.Data;
using ChocoLync.Filters;
using ChocoLync.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ChocoLync.Controllers
{
    public class ComplaintController : Controller
    {
        private readonly ApplicationDbContext _context;

        public ComplaintController(ApplicationDbContext context)
        {
            _context = context;
        }

        private int? EnsureCustomerRecord(string username)
        {
            var customer = _context.Customers.FirstOrDefault(c => c.Username == username);
            if (customer != null) return customer.Id;

            var user = _context.Users.FirstOrDefault(u => u.Username == username);
            if (user == null) return null;

            customer = new Customer
            {
                Name = username,
                Username = username,
                Password = user.Password
            };
            _context.Customers.Add(customer);
            _context.SaveChanges();

            return customer.Id;
        }

        [HttpGet]
        public IActionResult Create()
        {
            var username = HttpContext.Session.GetString("CustomerUsername")
                           ?? HttpContext.Session.GetString("Username");

            if (!string.IsNullOrEmpty(username))
            {
                var customer = _context.Customers.FirstOrDefault(c => c.Username == username);

                if (customer != null)
                {
                    ViewBag.CustomerName = customer.Name;
                    ViewBag.CustomerPhone = customer.Phone;
                }
                else
                {
                    ViewBag.CustomerName = username;
                }
            }

            return View();
        }

        [HttpPost]
        public IActionResult Create(Complaint complaint)
        {
            var username = HttpContext.Session.GetString("CustomerUsername")
                           ?? HttpContext.Session.GetString("Username");

            complaint.ComplaintDate = DateTime.Now;
            complaint.Status = "Pending";

            if (!string.IsNullOrEmpty(username))
            {
                complaint.CustomerId = EnsureCustomerRecord(username);

                if (string.IsNullOrEmpty(complaint.CustomerName))
                {
                    complaint.CustomerName = username;
                }
            }

            if (string.IsNullOrEmpty(complaint.CustomerName))
            {
                complaint.CustomerName = "Guest";
            }

            _context.Complaints.Add(complaint);
            _context.SaveChanges();

            TempData["Success"] = "Your complaint has been submitted successfully.";
            return RedirectToAction("MyComplaints");
        }

        [RoleAuthorize("Customer")]
        public IActionResult MyComplaints()
        {
            var username = HttpContext.Session.GetString("CustomerUsername");
            List<Complaint> complaints = new List<Complaint>();

            if (!string.IsNullOrEmpty(username))
            {
                var customerId = EnsureCustomerRecord(username);

                complaints = _context.Complaints
                    .Where(c => c.CustomerId == customerId)
                    .OrderByDescending(c => c.ComplaintDate)
                    .ToList();
            }

            return View(complaints);
        }

        [RoleAuthorize("Owner,Admin")]
        public IActionResult Index()
        {
            var complaints = _context.Complaints
                .OrderByDescending(c => c.ComplaintDate)
                .ToList();

            return View(complaints);
        }

        [RoleAuthorize("Owner,Admin")]
        public IActionResult Details(int id)
        {
            var complaint = _context.Complaints
                .FirstOrDefault(c => c.Id == id);

            if (complaint == null)
            {
                return NotFound();
            }

            return View(complaint);
        }

        [HttpPost]
        [RoleAuthorize("Owner,Admin")]
        public IActionResult UpdateStatus(int id, string status, string? currentHandler, string? adminResponse)
        {
            var complaint = _context.Complaints.Find(id);

            if (complaint == null)
            {
                return NotFound();
            }

            complaint.Status = status;
            complaint.CurrentHandler = currentHandler;
            complaint.AdminResponse = adminResponse;

            if (status == "Completed" || status == "Rejected")
            {
                complaint.ResolvedDate = DateTime.Now;
            }

            _context.SaveChanges();

            TempData["Success"] = "Complaint updated successfully.";
            return RedirectToAction("Details", new { id });
        }
    }
}
