﻿using ChocoLync.Data;
using ChocoLync.Filters;
using ChocoLync.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ChocoLync.Controllers
{
    public class ExpenseController : Controller
    {
        private readonly ApplicationDbContext _context;

        public ExpenseController(ApplicationDbContext context)
        {
            _context = context;
        }
        [RoleAuthorize("Owner,Admin")]
        public IActionResult Index()
        {
            var role = HttpContext.Session.GetString("Role");

            List<Expense> expenses;

            if (role == "Owner")
            {
                var adminUsernames = _context.Users
                    .Include(u => u.Role)
                    .Where(u => u.Role.Name == "Admin")
                    .Select(u => u.Username)
                    .ToList();

                expenses = _context.Expenses
                    .Where(e => e.CreatedBy != null && adminUsernames.Contains(e.CreatedBy))
                    .ToList();
            }
            else
            {
                expenses = _context.Expenses.ToList();
            }

            return View(expenses);
        }

        [RoleAuthorize("Owner,Admin")]
        public IActionResult Reports(string period, DateTime? startDate, DateTime? endDate)
        {
            DateTime from, to;

            if (period == "custom" && startDate.HasValue && endDate.HasValue)
            {
                from = startDate.Value.Date;
                to = endDate.Value.Date.AddDays(1).AddSeconds(-1);
            }
            else if (period == "yearly")
            {
                var now = DateTime.Now;
                from = new DateTime(now.Year, 1, 1);
                to = new DateTime(now.Year, 12, 31, 23, 59, 59);
            }
            else if (period == "lastmonth")
            {
                var now = DateTime.Now;
                from = new DateTime(now.Year, now.Month, 1).AddMonths(-1);
                to = new DateTime(now.Year, now.Month, 1).AddSeconds(-1);
            }
            else if (period == "monthly")
            {
                var now = DateTime.Now;
                from = new DateTime(now.Year, now.Month, 1);
                to = from.AddMonths(1).AddSeconds(-1);
            }
            else
            {
                var now = DateTime.Now;
                int diff = (7 + (now.DayOfWeek - DayOfWeek.Monday)) % 7;
                from = now.AddDays(-diff).Date;
                to = from.AddDays(7).AddSeconds(-1);
                period = "weekly";
            }

            ViewBag.SelectedPeriod = period;
            ViewBag.StartDate = from.ToString("yyyy-MM-dd");
            ViewBag.EndDate = to.ToString("yyyy-MM-dd");

            var expenses = _context.Expenses
                .Where(e => e.ExpenseDate >= from && e.ExpenseDate <= to)
                .OrderByDescending(e => e.ExpenseDate)
                .ToList();

            var completedOrderIds = _context.Orders
                .Where(o => o.Status == "Completed")
                .Select(o => o.Id);

            var salesTotal = _context.Sales
                .Where(s => !s.IsReplacement
                    && s.SaleDate >= from && s.SaleDate <= to
                    && completedOrderIds.Contains(s.OrderId ?? 0))
                .Sum(s => (decimal?)s.TotalAmount) ?? 0;

            var model = new ExpenseReportViewModel
            {
                Period = period,
                StartDate = from,
                EndDate = to,
                Expenses = expenses.Select(e => new ExpenseReportItem
                {
                    Date = e.ExpenseDate,
                    Title = e.Title,
                    Amount = e.Amount,
                    Description = e.Description ?? "-"
                }).ToList(),
                TotalExpenses = expenses.Sum(e => e.Amount),
                PeriodSalesTotal = salesTotal
            };

            return View(model);
        }

        [RoleAuthorize("Owner,Admin")]
        public IActionResult PrintReport(string period, DateTime? startDate, DateTime? endDate)
        {
            DateTime from, to;

            if (period == "custom" && startDate.HasValue && endDate.HasValue)
            {
                from = startDate.Value.Date;
                to = endDate.Value.Date.AddDays(1).AddSeconds(-1);
            }
            else if (period == "yearly")
            {
                var now = DateTime.Now;
                from = new DateTime(now.Year, 1, 1);
                to = new DateTime(now.Year, 12, 31, 23, 59, 59);
            }
            else if (period == "lastmonth")
            {
                var now = DateTime.Now;
                from = new DateTime(now.Year, now.Month, 1).AddMonths(-1);
                to = new DateTime(now.Year, now.Month, 1).AddSeconds(-1);
            }
            else if (period == "monthly")
            {
                var now = DateTime.Now;
                from = new DateTime(now.Year, now.Month, 1);
                to = from.AddMonths(1).AddSeconds(-1);
            }
            else
            {
                var now = DateTime.Now;
                int diff = (7 + (now.DayOfWeek - DayOfWeek.Monday)) % 7;
                from = now.AddDays(-diff).Date;
                to = from.AddDays(7).AddSeconds(-1);
                period = "weekly";
            }

            ViewBag.SelectedPeriod = period;
            ViewBag.StartDate = from.ToString("yyyy-MM-dd");
            ViewBag.EndDate = to.ToString("yyyy-MM-dd");

            var expenses = _context.Expenses
                .Where(e => e.ExpenseDate >= from && e.ExpenseDate <= to)
                .OrderByDescending(e => e.ExpenseDate)
                .ToList();

            var completedOrderIds = _context.Orders
                .Where(o => o.Status == "Completed")
                .Select(o => o.Id);

            var salesTotal = _context.Sales
                .Where(s => !s.IsReplacement
                    && s.SaleDate >= from && s.SaleDate <= to
                    && completedOrderIds.Contains(s.OrderId ?? 0))
                .Sum(s => (decimal?)s.TotalAmount) ?? 0;

            var model = new ExpenseReportViewModel
            {
                Period = period,
                StartDate = from,
                EndDate = to,
                Expenses = expenses.Select(e => new ExpenseReportItem
                {
                    Date = e.ExpenseDate,
                    Title = e.Title,
                    Amount = e.Amount,
                    Description = e.Description ?? "-"
                }).ToList(),
                TotalExpenses = expenses.Sum(e => e.Amount),
                PeriodSalesTotal = salesTotal
            };

            return View("PrintReport", model);
        }

        [RoleAuthorize("Owner,Admin")]
        public IActionResult Create()
        {
            return View();
        }

        // SAVE EXPENSE
        [HttpPost]
        [RoleAuthorize("Owner,Admin")]
        public IActionResult Create(Expense expense)
        {
            if (ModelState.IsValid)
            {
                expense.CreatedBy = HttpContext.Session.GetString("Username");
                _context.Expenses.Add(expense);

                _context.SaveChanges();

                return RedirectToAction("Index");
            }

            return View(expense);
        }

        // EDIT PAGE
        [RoleAuthorize("Admin")]
        public IActionResult Edit(int id)
        {
            var expense =
                _context.Expenses.Find(id);

            if (expense == null)
            {
                return NotFound();
            }

            return View(expense);
        }

        // UPDATE EXPENSE
        [HttpPost]
        [RoleAuthorize("Admin")]
        public IActionResult Edit(Expense expense)
        {
            if (ModelState.IsValid)
            {
                _context.Expenses.Update(expense);

                _context.SaveChanges();

                return RedirectToAction("Index");
            }

            return View(expense);
        }

        // DELETE PAGE
        [RoleAuthorize("Admin")]
        public IActionResult Delete(int id)
        {
            var expense =
                _context.Expenses.Find(id);

            if (expense == null)
            {
                return NotFound();
            }

            return View(expense);
        }

        // DELETE EXPENSE
        [HttpPost]
        [RoleAuthorize("Admin")]
        public IActionResult Delete(Expense expense)
        {
            var existingExpense =
                _context.Expenses.Find(expense.Id);

            if (existingExpense == null)
            {
                return NotFound();
            }

            _context.Expenses.Remove(existingExpense);

            _context.SaveChanges();

            return RedirectToAction("Index");
        }
    }
}