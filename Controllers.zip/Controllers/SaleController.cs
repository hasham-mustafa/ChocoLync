﻿using ChocoLync.Data;
using ChocoLync.Filters;
using ChocoLync.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace ChocoLync.Controllers
{
    public class SaleController : Controller
    {
        private readonly ApplicationDbContext _context;

        public SaleController(ApplicationDbContext context)
        {
            _context = context;
        }
        [RoleAuthorize("Owner,Admin")]
        public IActionResult Index()
        {
            var completedOrderIds = _context.Orders
                .Where(o => o.Status == "Completed")
                .Select(o => o.Id);

            var sales = _context.Sales
                .Include(s => s.Product)
                .Include(s => s.Customer)
                .Include(s => s.Employee)
                .Where(s => completedOrderIds.Contains(s.OrderId ?? 0))
                .ToList();

            return View(sales);
        }

        [RoleAuthorize("Owner,Admin")]
        public IActionResult Reports(string period, DateTime? startDate, DateTime? endDate)
        {
            DateTime from, to;

            if (period == "custom" && startDate.HasValue && endDate.HasValue)
            {
                from = startDate.Value.Date;
                to = endDate.Value.Date.AddDays(1).AddSeconds(-1);
            }
            else if (period == "yearly")
            {
                var now = DateTime.Now;
                from = new DateTime(now.Year, 1, 1);
                to = new DateTime(now.Year, 12, 31, 23, 59, 59);
            }
            else if (period == "lastmonth")
            {
                var now = DateTime.Now;
                from = new DateTime(now.Year, now.Month, 1).AddMonths(-1);
                to = new DateTime(now.Year, now.Month, 1).AddSeconds(-1);
            }
            else if (period == "monthly")
            {
                var now = DateTime.Now;
                from = new DateTime(now.Year, now.Month, 1);
                to = from.AddMonths(1).AddSeconds(-1);
            }
            else
            {
                var now = DateTime.Now;
                int diff = (7 + (now.DayOfWeek - DayOfWeek.Monday)) % 7;
                from = now.AddDays(-diff).Date;
                to = from.AddDays(7).AddSeconds(-1);
                period = "weekly";
            }

            ViewBag.SelectedPeriod = period;
            ViewBag.StartDate = from.ToString("yyyy-MM-dd");
            ViewBag.EndDate = to.ToString("yyyy-MM-dd");

            var completedOrderIds = _context.Orders
                .Where(o => o.Status == "Completed")
                .Select(o => o.Id);

            var sales = _context.Sales
                .Include(s => s.Product)
                .Include(s => s.Customer)
                .Include(s => s.Employee)
                .Where(s => !s.IsReplacement
                    && s.SaleDate >= from && s.SaleDate <= to
                    && completedOrderIds.Contains(s.OrderId ?? 0))
                .OrderByDescending(s => s.SaleDate)
                .ToList();

            var model = new SaleReportViewModel
            {
                Period = period,
                StartDate = from,
                EndDate = to,
                Sales = sales.Select(s => new SaleReportItem
                {
                    Date = s.SaleDate,
                    Product = s.Product?.Name ?? "-",
                    Customer = s.Customer?.Name ?? "-",
                    Employee = s.Employee?.Name ?? "-",
                    Quantity = s.Quantity != 0 ? s.Quantity : s.QuantitySold,
                    TotalAmount = s.TotalAmount,
                    Profit = s.Profit
                }).ToList(),
                TotalAmount = sales.Sum(s => s.TotalAmount),
                TotalQuantity = sales.Sum(s => s.Quantity != 0 ? s.Quantity : s.QuantitySold),
                TotalProfit = sales.Sum(s => s.Profit)
            };

            return View(model);
        }

        [RoleAuthorize("Owner,Admin")]
        public IActionResult PrintReport(string period, DateTime? startDate, DateTime? endDate)
        {
            DateTime from, to;

            if (period == "custom" && startDate.HasValue && endDate.HasValue)
            {
                from = startDate.Value.Date;
                to = endDate.Value.Date.AddDays(1).AddSeconds(-1);
            }
            else if (period == "yearly")
            {
                var now = DateTime.Now;
                from = new DateTime(now.Year, 1, 1);
                to = new DateTime(now.Year, 12, 31, 23, 59, 59);
            }
            else if (period == "lastmonth")
            {
                var now = DateTime.Now;
                from = new DateTime(now.Year, now.Month, 1).AddMonths(-1);
                to = new DateTime(now.Year, now.Month, 1).AddSeconds(-1);
            }
            else if (period == "monthly")
            {
                var now = DateTime.Now;
                from = new DateTime(now.Year, now.Month, 1);
                to = from.AddMonths(1).AddSeconds(-1);
            }
            else
            {
                var now = DateTime.Now;
                int diff = (7 + (now.DayOfWeek - DayOfWeek.Monday)) % 7;
                from = now.AddDays(-diff).Date;
                to = from.AddDays(7).AddSeconds(-1);
                period = "weekly";
            }

            ViewBag.SelectedPeriod = period;
            ViewBag.StartDate = from.ToString("yyyy-MM-dd");
            ViewBag.EndDate = to.ToString("yyyy-MM-dd");

            var completedOrderIds = _context.Orders
                .Where(o => o.Status == "Completed")
                .Select(o => o.Id);

            var sales = _context.Sales
                .Include(s => s.Product)
                .Include(s => s.Customer)
                .Include(s => s.Employee)
                .Where(s => !s.IsReplacement
                    && s.SaleDate >= from && s.SaleDate <= to
                    && completedOrderIds.Contains(s.OrderId ?? 0))
                .OrderByDescending(s => s.SaleDate)
                .ToList();

            var model = new SaleReportViewModel
            {
                Period = period,
                StartDate = from,
                EndDate = to,
                Sales = sales.Select(s => new SaleReportItem
                {
                    Date = s.SaleDate,
                    Product = s.Product?.Name ?? "-",
                    Customer = s.Customer?.Name ?? "-",
                    Employee = s.Employee?.Name ?? "-",
                    Quantity = s.Quantity != 0 ? s.Quantity : s.QuantitySold,
                    TotalAmount = s.TotalAmount,
                    Profit = s.Profit
                }).ToList(),
                TotalAmount = sales.Sum(s => s.TotalAmount),
                TotalQuantity = sales.Sum(s => s.Quantity != 0 ? s.Quantity : s.QuantitySold),
                TotalProfit = sales.Sum(s => s.Profit)
            };

            return View("PrintReport", model);
        }

        [RoleAuthorize("Owner,Admin")]
        public IActionResult Create()
        {
            ViewBag.Products =
                new SelectList(
                    _context.Products,
                    "Id",
                    "Name");

            ViewBag.Customers =
                new SelectList(
                    _context.Customers,
                    "Id",
                    "Name");

            ViewBag.Employees =
                new SelectList(
                    _context.Employees,
                    "Id",
                    "Name");

            return View();
        }

        // SAVE SALE
        [HttpPost]
        [RoleAuthorize("Owner,Admin")]
        public IActionResult Create(Sale sale)
        {
            if (ModelState.IsValid)
            {
                _context.Sales.Add(sale);

                _context.SaveChanges();

                return RedirectToAction("Index");
            }

            ViewBag.Products =
                new SelectList(
                    _context.Products,
                    "Id",
                    "Name");

            ViewBag.Customers =
                new SelectList(
                    _context.Customers,
                    "Id",
                    "Name");

            ViewBag.Employees =
                new SelectList(
                    _context.Employees,
                    "Id",
                    "Name");

            return View(sale);
        }

        // EDIT PAGE
        [RoleAuthorize("Owner,Admin")]
        public IActionResult Edit(int id)
        {
            var sale = _context.Sales.Find(id);

            if (sale == null)
            {
                return NotFound();
            }

            ViewBag.Products =
                new SelectList(
                    _context.Products,
                    "Id",
                    "Name",
                    sale.ProductId);

            ViewBag.Customers =
                new SelectList(
                    _context.Customers,
                    "Id",
                    "Name",
                    sale.CustomerId);

            ViewBag.Employees =
                new SelectList(
                    _context.Employees,
                    "Id",
                    "Name",
                    sale.EmployeeId);

            return View(sale);
        }

        // UPDATE SALE
        [HttpPost]
        [RoleAuthorize("Owner,Admin")]
        public IActionResult Edit(Sale sale)
        {
            if (ModelState.IsValid)
            {
                _context.Sales.Update(sale);

                _context.SaveChanges();

                return RedirectToAction("Index");
            }

            return View(sale);
        }

        // DELETE PAGE
        [RoleAuthorize("Owner,Admin")]
        public IActionResult Delete(int id)
        {
            var sale = _context.Sales
                .Include(s => s.Product)
                .FirstOrDefault(s => s.Id == id);

            if (sale == null)
            {
                return NotFound();
            }

            return View(sale);
        }

        // DELETE SALE
        [HttpPost]
        [RoleAuthorize("Owner,Admin")]
        public IActionResult Delete(Sale sale)
        {
            var existingSale =
                _context.Sales.Find(sale.Id);

            if (existingSale == null)
            {
                return NotFound();
            }

            _context.Sales.Remove(existingSale);

            _context.SaveChanges();

            return RedirectToAction("Index");
        }
    }
}