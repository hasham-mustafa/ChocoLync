﻿using ChocoLync.Data;
using ChocoLync.Filters;
using ChocoLync.Models;
using Microsoft.AspNetCore.Mvc;

namespace ChocoLync.Controllers
{
    public class CustomerController : Controller
    {
        private readonly ApplicationDbContext _context;

        public CustomerController(ApplicationDbContext context)
        {
            _context = context;
        }
        [RoleAuthorize("Admin")]
        // CUSTOMER LIST
        public IActionResult Index()
        {
            var customers = _context.Customers.ToList();

            return View(customers);
        }

        // OPEN CREATE PAGE
        public IActionResult Create()
        {
            return View();
        }

        // SAVE CUSTOMER
        [HttpPost]
        public IActionResult Create(Customer customer)
        {
            if (ModelState.IsValid)
            {
                _context.Customers.Add(customer);

                _context.SaveChanges();

                return RedirectToAction("Index");
            }

            return View(customer);
        }

        // OPEN EDIT PAGE
        public IActionResult Edit(int id)
        {
            var customer = _context.Customers.Find(id);

            if (customer == null)
            {
                return NotFound();
            }

            return View(customer);
        }

        // UPDATE CUSTOMER
        [HttpPost]
        public IActionResult Edit(Customer customer)
        {
            if (ModelState.IsValid)
            {
                _context.Customers.Update(customer);

                _context.SaveChanges();

                return RedirectToAction("Index");
            }

            return View(customer);
        }

        // OPEN DELETE PAGE
        public IActionResult Delete(int id)
        {
            var customer = _context.Customers.Find(id);

            if (customer == null)
            {
                return NotFound();
            }

            return View(customer);
        }

        // DELETE CUSTOMER
        [HttpPost]
        public IActionResult Delete(Customer customer)
        {
            var existingCustomer =
                _context.Customers.Find(customer.Id);

            if (existingCustomer == null)
            {
                return NotFound();
            }

            _context.Customers.Remove(existingCustomer);

            _context.SaveChanges();

            return RedirectToAction("Index");
        }



           
        }
    }

