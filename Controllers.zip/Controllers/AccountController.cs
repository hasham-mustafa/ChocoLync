﻿using ChocoLync.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ChocoLync.Controllers
{
    public class AccountController : Controller
    {
        private readonly ApplicationDbContext _context;

        public AccountController(ApplicationDbContext context)
        {
            _context = context;
        }

        // LOGIN PAGE
        public IActionResult Login()
        {
            return View();
        }


        [HttpGet]
        public IActionResult StaffLogin()
        {
            return View();
        }

        [HttpPost]
        public IActionResult StaffLogin(
            string username,
            string password)
        {
            var user =
                _context.Users
                .Include(x => x.Role)
                .Include(x => x.Employee)
                .FirstOrDefault(x =>
                    x.Username == username &&
                    x.Password == password);

            if (user == null)
            {
                ViewBag.Error =
                    "Invalid Credentials";

                return View();
            }

            if (user.Role.Name == "Customer")
            {
                ViewBag.Error =
                    "Customers use normal login.";

                return View();
            }

            HttpContext.Session.SetString(
                "Username",
                user.Username);

            HttpContext.Session.SetString(
                "Role",
                user.Role.Name);

            string profileImage = null;

            if (user.Role.Name == "Admin" || user.Role.Name == "Owner")
            {
                profileImage = user.ProfileImage;
            }
            else if (user.Role.Name == "Employee" && user.Employee != null)
            {
                profileImage = user.Employee.ProfileImage;
            }

            HttpContext.Session.SetString(
                "ProfileImage",
                profileImage ?? "");

            if (user.Role.Name == "Admin" || user.Role.Name == "Owner")
            {
                return RedirectToAction(
                    "Index",
                    "Dashboard");
            }

            return RedirectToAction(
                "EmployeeDashboard",
                "Dashboard");
        }
        // LOGIN CHECK
        [HttpPost]
        public IActionResult Login(string username, string password)
        {
            var user = _context.Users
                .Include(u => u.Role)
                .Include(u => u.Employee)
                .FirstOrDefault(u =>
                    u.Username == username &&
                    u.Password == password);

            if (user != null)
            {
                // SAVE SESSION
                HttpContext.Session.SetString(
                    "Username",
                    user.Username);
                HttpContext.Session.SetString(
                    "CustomerUsername",
                    user.Username);

                HttpContext.Session.SetString(
                    "Role",
                    user.Role.Name);

                string profileImage = null;

                if (user.Role.Name == "Admin" || user.Role.Name == "Owner")
                {
                    profileImage = user.ProfileImage;
                }
                else if (user.Role.Name == "Employee" && user.Employee != null)
                {
                    profileImage = user.Employee.ProfileImage;
                }
                else if (user.Role.Name == "Customer")
                {
                    var customer = _context.Customers
                        .FirstOrDefault(x => x.Username == username);
                    if (customer != null)
                    {
                        profileImage = customer.ProfileImage;
                    }
                }

                HttpContext.Session.SetString(
                    "ProfileImage",
                    profileImage ?? "");

                // ROLE BASED REDIRECT
                if (user.Role.Name == "Admin" || user.Role.Name == "Owner")
                {
                    return RedirectToAction(
                        "Index",
                        "Dashboard");
                }

                else if (user.Role.Name == "Employee")
                {
                    return RedirectToAction(
                        "EmployeeDashboard",
                        "Dashboard");
                }

                else
                {
                    return RedirectToAction(
                        "Index",
                        "Shop");
                }
            }

            ViewBag.Error = "Invalid Username or Password";

            return View();
        }

        // REGISTER PAGE
        public IActionResult Register()
        {
            return View();
        }


        // SAVE REGISTER
        [HttpPost]
        public IActionResult Register(
            string username,
            string password)
        {
            // CUSTOMER ROLE
            var customerRole = _context.Roles
                .FirstOrDefault(r => r.Name == "Customer");

            if (customerRole == null)
            {
                ViewBag.Error = "Customer role not found";

                return View();
            }

            // CHECK EXISTING USER
            var existingUser = _context.Users
                .FirstOrDefault(u => u.Username == username);

            if (existingUser != null)
            {
                ViewBag.Error = "Username already exists";

                return View();
            }

            var user = new Models.User
            {
                Username = username,
                Password = password,
                RoleId = customerRole.Id
            };

            _context.Users.Add(user);
            _context.SaveChanges();

            var customer = new Models.Customer
            {
                Name = username,
                Username = username,
                Password = password
            };

            _context.Customers.Add(customer);
            _context.SaveChanges();

            return RedirectToAction("Login");
        }
        // LOGOUT
        public IActionResult Logout()
        {
            HttpContext.Session.Clear();

            return RedirectToAction(
                "Index",
                "Shop");
        }
        public IActionResult AccessDenied()
        {
            return View();
        }
    }
}