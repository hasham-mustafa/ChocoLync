using ChocoLync.Data;
using ChocoLync.Filters;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ChocoLync.Controllers
{
    public class AdminController : Controller
    {
        private readonly ApplicationDbContext _context;

        public AdminController(ApplicationDbContext context)
        {
            _context = context;
        }

        [RoleAuthorize("Owner,Admin")]
        public IActionResult Profile()
        {
            var username =
                HttpContext.Session
                .GetString("Username");

            var user =
                _context.Users
                .Include(x => x.Role)
                .FirstOrDefault(x =>
                    x.Username == username);

            if (user == null)
            {
                return NotFound();
            }

            return View(user);
        }

        [HttpGet]
        [RoleAuthorize("Owner,Admin")]
        public IActionResult EditProfile()
        {
            var username =
                HttpContext.Session
                .GetString("Username");

            var user =
                _context.Users
                .Include(x => x.Role)
                .FirstOrDefault(x =>
                    x.Username == username);

            if (user == null)
            {
                return NotFound();
            }

            return View(user);
        }

        [HttpPost]
        [RoleAuthorize("Owner,Admin")]
        public IActionResult EditProfile(
            string username,
            string password,
            IFormFile? ImageFile)
        {
            var existingUser =
                _context.Users
                .Include(x => x.Role)
                .FirstOrDefault(x =>
                    x.Username == username &&
                    x.Username ==
                        HttpContext.Session
                        .GetString("Username"));

            if (existingUser == null)
            {
                return NotFound();
            }

            if (!string.IsNullOrEmpty(password))
            {
                existingUser.Password = password;
            }

            if (ImageFile != null)
            {
                string folder =
                    Path.Combine(
                        Directory.GetCurrentDirectory(),
                        "wwwroot/uploads");

                string fileName =
                    Guid.NewGuid().ToString()
                    + Path.GetExtension(ImageFile.FileName);

                string filePath =
                    Path.Combine(folder, fileName);

                using (var stream =
                    new FileStream(filePath,
                    FileMode.Create))
                {
                    ImageFile.CopyTo(stream);
                }

                existingUser.ProfileImage =
                    "uploads/" + fileName;
            }

            _context.SaveChanges();

            HttpContext.Session.SetString(
                "ProfileImage",
                existingUser.ProfileImage ?? "");

            return RedirectToAction("Profile");
        }
    }
}
