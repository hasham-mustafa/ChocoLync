﻿using ChocoLync.Data;
using ChocoLync.Filters;
using ChocoLync.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace ChocoLync.Controllers
{
    public class UserController : Controller
    {
        private readonly ApplicationDbContext _context;

        public UserController(ApplicationDbContext context)
        {
            _context = context;
        }
        [RoleAuthorize("Admin")]
        // USER LIST
        public IActionResult Index()
        {
            var users = _context.Users
                .Include(u => u.Role)
                .Include(u => u.Employee)
                .ToList();

            return View(users);
        }

        // CREATE PAGE
        public IActionResult Create()
        {
            ViewBag.Roles = new SelectList(
                _context.Roles,
                "Id",
                "Name");

            ViewBag.Employees = new SelectList(
                _context.Employees,
                "Id",
                "Name");

            return View();
        }

        // SAVE USER
        [HttpPost]
        public IActionResult Create(User user)
        {
            if (ModelState.IsValid)
            {
                _context.Users.Add(user);

                _context.SaveChanges();

                return RedirectToAction("Index");
            }

            ViewBag.Roles = new SelectList(
                _context.Roles,
                "Id",
                "Name");

            ViewBag.Employees = new SelectList(
                _context.Employees,
                "Id",
                "Name");

            return View(user);
        }

        // EDIT PAGE
        public IActionResult Edit(int id)
        {
            var user = _context.Users.Find(id);

            if (user == null)
            {
                return NotFound();
            }

            ViewBag.Roles = new SelectList(
                _context.Roles,
                "Id",
                "Name",
                user.RoleId);

            ViewBag.Employees = new SelectList(
                _context.Employees,
                "Id",
                "Name",
                user.EmployeeId);

            return View(user);
        }

        // UPDATE USER
        [HttpPost]
        public IActionResult Edit(User user)
        {
            if (ModelState.IsValid)
            {
                _context.Users.Update(user);

                _context.SaveChanges();

                return RedirectToAction("Index");
            }

            return View(user);
        }

        // DELETE PAGE
        public IActionResult Delete(int id)
        {
            var user = _context.Users
                .Include(u => u.Role)
                .Include(u => u.Employee)
                .FirstOrDefault(u => u.Id == id);

            if (user == null)
            {
                return NotFound();
            }

            return View(user);
        }

        // DELETE USER
        [HttpPost]
        public IActionResult Delete(User user)
        {
            var existingUser =
                _context.Users.Find(user.Id);

            if (existingUser == null)
            {
                return NotFound();
            }

            _context.Users.Remove(existingUser);

            _context.SaveChanges();

            return RedirectToAction("Index");
        }
    }
}