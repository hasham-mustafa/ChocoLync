﻿using ChocoLync.Data;
using ChocoLync.Filters;
using ChocoLync.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace ChocoLync.Controllers
{
    public class PurchaseController : Controller
    {
        private readonly ApplicationDbContext _context;

        public PurchaseController(ApplicationDbContext context)
        {
            _context = context;
        }
        [RoleAuthorize("Admin")]
        // PURCHASE LIST
        public IActionResult Index()
        {
            var purchases = _context.Purchases
                .Include(p => p.Product)
                .ToList();

            return View(purchases);
        }

        // CREATE PAGE
        public IActionResult Create()
        {
            ViewBag.Products =
                new SelectList(
                    _context.Products,
                    "Id",
                    "Name");

            return View();
        }

        // SAVE PURCHASE
        [HttpPost]
        public IActionResult Create(Purchase purchase)
        {
            if (ModelState.IsValid)
            {
                _context.Purchases.Add(purchase);

                // STOCK INCREASE LOGIC
                var product = _context.Products
                    .FirstOrDefault(p =>
                        p.Id == purchase.ProductId);

                if (product != null)
                {
                    product.StockQuantity +=
                        purchase.QuantityBought;

                    _context.Products.Update(product);
                }

                _context.SaveChanges();

                return RedirectToAction("Index");
            }

            ViewBag.Products =
                new SelectList(
                    _context.Products,
                    "Id",
                    "Name");

            return View(purchase);
        }

        // EDIT PAGE
        public IActionResult Edit(int id)
        {
            var purchase =
                _context.Purchases.Find(id);

            if (purchase == null)
            {
                return NotFound();
            }

            ViewBag.Products =
                new SelectList(
                    _context.Products,
                    "Id",
                    "Name",
                    purchase.ProductId);

            return View(purchase);
        }

        // UPDATE PURCHASE
        [HttpPost]
        public IActionResult Edit(Purchase purchase)
        {
            if (ModelState.IsValid)
            {
                _context.Purchases.Update(purchase);

                _context.SaveChanges();

                return RedirectToAction("Index");
            }

            return View(purchase);
        }

        // DELETE PAGE
        public IActionResult Delete(int id)
        {
            var purchase = _context.Purchases
                .Include(p => p.Product)
                .FirstOrDefault(p => p.Id == id);

            if (purchase == null)
            {
                return NotFound();
            }

            return View(purchase);
        }

        // DELETE PURCHASE
        [HttpPost]
        public IActionResult Delete(Purchase purchase)
        {
            var existingPurchase =
                _context.Purchases.Find(purchase.Id);

            if (existingPurchase == null)
            {
                return NotFound();
            }

            _context.Purchases.Remove(existingPurchase);

            _context.SaveChanges();

            return RedirectToAction("Index");
        }
    }
}