﻿using ChocoLync.Data;
using ChocoLync.Filters;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;


namespace ChocoLync.Controllers
{
    [RoleAuthorize("Employee")]
    public class EmployeeOrderController : Controller
    {
        private readonly ApplicationDbContext _context;

        public EmployeeOrderController(
            ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            var orders =
                _context.Orders
                .Include(x => x.OrderItems)
                .ThenInclude(x => x.Product)
                .ToList();

            return View(orders);
        }

        public IActionResult LowStockProducts()
        {
            var products =
                _context.Products
                .Where(x => x.StockQuantity <= 5)
                .ToList();

            return View(products);
        }
    }
}