﻿using ChocoLync.Data;
using ChocoLync.Filters;
using ChocoLync.Models;
using Microsoft.AspNetCore.Mvc;

namespace ChocoLync.Controllers
{
    public class DepartmentController : Controller
    {
        private readonly ApplicationDbContext _context;

        public DepartmentController(ApplicationDbContext context)
        {
            _context = context;
        }
        [RoleAuthorize("Admin")]
        // DEPARTMENT LIST
        public IActionResult Index()
        {
            var departments = _context.Departments.ToList();

            return View(departments);
        }

        // OPEN CREATE PAGE
        public IActionResult Create()
        {
            return View();
        }

        // SAVE DEPARTMENT
        [HttpPost]
        public IActionResult Create(Department department)
        {
            if (ModelState.IsValid)
            {
                _context.Departments.Add(department);

                _context.SaveChanges();

                return RedirectToAction("Index");
            }

            return View(department);
        }

        // OPEN EDIT PAGE
        public IActionResult Edit(int id)
        {
            var department = _context.Departments.Find(id);

            if (department == null)
            {
                return NotFound();
            }

            return View(department);
        }

        // UPDATE DEPARTMENT
        [HttpPost]
        public IActionResult Edit(Department department)
        {
            if (ModelState.IsValid)
            {
                _context.Departments.Update(department);

                _context.SaveChanges();

                return RedirectToAction("Index");
            }

            return View(department);
        }

        // OPEN DELETE PAGE
        public IActionResult Delete(int id)
        {
            var department = _context.Departments.Find(id);

            if (department == null)
            {
                return NotFound();
            }

            return View(department);
        }

        // DELETE DEPARTMENT
        [HttpPost]
        public IActionResult Delete(Department department)
        {
            var existingDepartment =
                _context.Departments.Find(department.Id);

            if (existingDepartment == null)
            {
                return NotFound();
            }

            _context.Departments.Remove(existingDepartment);

            _context.SaveChanges();

            return RedirectToAction("Index");
        }
    }
}