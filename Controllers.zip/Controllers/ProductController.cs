﻿using ChocoLync.Data;
using ChocoLync.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Hosting;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Mvc.Rendering;
using ChocoLync.Filters;

namespace ChocoLync.Controllers
{
    public class ProductController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly IWebHostEnvironment _webHostEnvironment;

        public ProductController(
            ApplicationDbContext context,
            IWebHostEnvironment webHostEnvironment)
        {
            _context = context;
            _webHostEnvironment = webHostEnvironment;
        }

        [RoleAuthorize("Owner,Admin")]
        public IActionResult LowStock()
        {
            var products =
                _context.Products
                .Include(p => p.Category)
                .Where(x => x.StockQuantity <= x.AlertQuantity)
                .ToList();

            return View(products);
        }

        [RoleAuthorize("Owner,Admin")]
        public IActionResult Index(int page = 1, int pageSize = 10)
        {
            var total = _context.Products.Count();

            var products = _context.Products
                .Include(p => p.Category)
                .OrderByDescending(p => p.Id)
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .ToList();

            ViewBag.PageIndex = page;
            ViewBag.TotalPages = (int)Math.Ceiling(total / (double)pageSize);
            ViewBag.PageSize = pageSize;
            ViewBag.TotalCount = total;

            return View(products);
        }

        [RoleAuthorize("Admin")]
        public IActionResult Create()
        {
            ViewBag.CategoryList = _context.Categories.ToList();
            return View();
        }

        [HttpPost]
        [RoleAuthorize("Admin")]
        public IActionResult Create(Product product, IFormFile ImageFile)
        {
            ViewBag.CategoryList = _context.Categories.ToList();

            if (ModelState.IsValid)
            {
                if (ImageFile != null)
                {
                    string uploadFolder = Path.Combine(
                        _webHostEnvironment.WebRootPath,
                        "uploads");

                    string fileName = Guid.NewGuid().ToString()
                                      + "_"
                                      + ImageFile.FileName;

                    string filePath = Path.Combine(uploadFolder, fileName);

                    using (var stream = new FileStream(filePath, FileMode.Create))
                    {
                        ImageFile.CopyTo(stream);
                    }

                    product.ImagePath = "/uploads/" + fileName;
                }

                _context.Products.Add(product);
                _context.SaveChanges();

                return RedirectToAction("Index");
            }

            return View(product);
        }

        [RoleAuthorize("Admin")]
        public IActionResult Edit(int id)
        {
            var product = _context.Products.Find(id);

            if (product == null)
            {
                return NotFound();
            }

            ViewBag.CategoryList = _context.Categories.ToList();

            return View(product);
        }

        [HttpPost]
        [RoleAuthorize("Admin")]
        public IActionResult Edit(Product product, IFormFile ImageFile)
        {
            ViewBag.CategoryList = _context.Categories.ToList();

            if (ModelState.IsValid)
            {
                var existing = _context.Products.Find(product.Id);
                if (existing == null) return NotFound();

                existing.Name = product.Name;
                existing.SKU = product.SKU;
                existing.Brand = product.Brand;
                existing.Unit = product.Unit;
                existing.Weight = product.Weight;
                existing.CategoryId = product.CategoryId;
                existing.BuyingPrice = product.BuyingPrice;
                existing.Price = product.Price;
                existing.StockQuantity = product.StockQuantity;
                existing.AlertQuantity = product.AlertQuantity;
                existing.Description = product.Description;

                if (ImageFile != null)
                {
                    if (!string.IsNullOrEmpty(existing.ImagePath))
                    {
                        string oldPath = Path.Combine(
                            _webHostEnvironment.WebRootPath,
                            existing.ImagePath.TrimStart('/'));
                        if (System.IO.File.Exists(oldPath))
                            System.IO.File.Delete(oldPath);
                    }

                    string uploadFolder = Path.Combine(
                        _webHostEnvironment.WebRootPath, "uploads");
                    string fileName = Guid.NewGuid().ToString() + "_" + ImageFile.FileName;
                    string filePath = Path.Combine(uploadFolder, fileName);

                    using (var stream = new FileStream(filePath, FileMode.Create))
                    {
                        ImageFile.CopyTo(stream);
                    }

                    existing.ImagePath = "/uploads/" + fileName;
                }

                _context.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(product);
        }

        [RoleAuthorize("Admin")]
        public IActionResult Delete(int id)
        {
            var product = _context.Products.Find(id);

            if (product == null)
            {
                return NotFound();
            }

            return View(product);
        }

        [HttpPost]
        [RoleAuthorize("Admin")]
        public IActionResult Delete(Product product)
        {
            var existingProduct = _context.Products.Find(product.Id);

            if (existingProduct == null)
            {
                return NotFound();
            }

            if (!string.IsNullOrEmpty(existingProduct.ImagePath))
            {
                string imagePath = Path.Combine(
                    _webHostEnvironment.WebRootPath,
                    existingProduct.ImagePath.TrimStart('/'));

                if (System.IO.File.Exists(imagePath))
                {
                    System.IO.File.Delete(imagePath);
                }
            }

            _context.Products.Remove(existingProduct);
            _context.SaveChanges();

            return RedirectToAction("Index");
        }

        [RoleAuthorize("Owner,Admin")]
        public IActionResult GetProductsJson()
        {
            var products = _context.Products
                .Select(p => new { p.Id, p.Name, p.StockQuantity, p.Price })
                .ToList();
            return Json(products);
        }
    }
}
