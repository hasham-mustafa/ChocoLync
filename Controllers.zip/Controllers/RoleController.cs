﻿using ChocoLync.Data;
using ChocoLync.Filters;
using ChocoLync.Models;
using Microsoft.AspNetCore.Mvc;

namespace ChocoLync.Controllers
{
    public class RoleController : Controller
    {
        private readonly ApplicationDbContext _context;

        public RoleController(ApplicationDbContext context)
        {
            _context = context;
        }
        [RoleAuthorize("Admin")]
        // ROLE LIST
        public IActionResult Index()
        {
            var roles =
                _context.Roles.ToList();

            return View(roles);
        }

        // CREATE PAGE
        public IActionResult Create()
        {
            return View();
        }

        // SAVE ROLE
        [HttpPost]
        public IActionResult Create(Role role)
        {
            if (ModelState.IsValid)
            {
                _context.Roles.Add(role);

                _context.SaveChanges();

                return RedirectToAction("Index");
            }

            return View(role);
        }

        // EDIT PAGE
        public IActionResult Edit(int id)
        {
            var role =
                _context.Roles.Find(id);

            if (role == null)
            {
                return NotFound();
            }

            return View(role);
        }

        // UPDATE ROLE
        [HttpPost]
        public IActionResult Edit(Role role)
        {
            if (ModelState.IsValid)
            {
                _context.Roles.Update(role);

                _context.SaveChanges();

                return RedirectToAction("Index");
            }

            return View(role);
        }

        // DELETE PAGE
        public IActionResult Delete(int id)
        {
            var role =
                _context.Roles.Find(id);

            if (role == null)
            {
                return NotFound();
            }

            return View(role);
        }

        // DELETE ROLE
        [HttpPost]
        public IActionResult Delete(Role role)
        {
            var existingRole =
                _context.Roles.Find(role.Id);

            if (existingRole == null)
            {
                return NotFound();
            }

            _context.Roles.Remove(existingRole);

            _context.SaveChanges();

            return RedirectToAction("Index");
        }
    }
}