using ChocoLync.Data;
using ChocoLync.Filters;
using ChocoLync.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ChocoLync.Controllers
{
    [RoleAuthorize("Admin")]
    public class ReplacementController : Controller
    {
        private readonly ApplicationDbContext _context;

        public ReplacementController(ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            var replacements = _context.Replacements
                .Include(r => r.Order)
                .Include(r => r.OriginalProduct)
                .Include(r => r.ReplacementProduct)
                .OrderByDescending(r => r.ReplacementDate)
                .ToList();

            return View(replacements);
        }

        public IActionResult Create()
        {
            ViewBag.Orders = _context.Orders
                .OrderByDescending(o => o.OrderDate)
                .ToList();

            return View();
        }

        [HttpPost]
        public IActionResult Create(Replacement replacement)
        {
            if (ModelState.IsValid)
            {
                replacement.ReplacementDate = DateTime.Now;
                replacement.Status = "Pending";
                _context.Replacements.Add(replacement);
                _context.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.Orders = _context.Orders
                .OrderByDescending(o => o.OrderDate)
                .ToList();

            return View(replacement);
        }

        public IActionResult Process(int id)
        {
            var replacement = _context.Replacements
                .Include(r => r.OriginalProduct)
                .Include(r => r.ReplacementProduct)
                .FirstOrDefault(r => r.Id == id);

            if (replacement == null) return NotFound();
            if (replacement.Status != "Pending") return BadRequest("Only pending replacements can be processed.");

            return View(replacement);
        }

        [HttpPost]
        public IActionResult Process(Replacement model)
        {
            var replacement = _context.Replacements
                .Include(r => r.OriginalProduct)
                .Include(r => r.ReplacementProduct)
                .FirstOrDefault(r => r.Id == model.Id);

            if (replacement == null) return NotFound();
            if (replacement.Status != "Pending") return BadRequest("Only pending replacements can be processed.");

            if (replacement.OriginalProduct == null || replacement.ReplacementProduct == null)
                return BadRequest("Products not found.");

            if (replacement.ReplacementProduct.StockQuantity < replacement.Quantity)
            {
                ModelState.AddModelError("", "Insufficient stock of replacement product.");
                return View(replacement);
            }

            replacement.OriginalProduct.StockQuantity += replacement.Quantity;
            replacement.ReplacementProduct.StockQuantity -= replacement.Quantity;

            replacement.Status = "Processed";

            // Update the OrderItem to point to the replacement product
            var orderItem = _context.OrderItems
                .FirstOrDefault(oi => oi.OrderId == replacement.OrderId
                    && oi.ProductId == replacement.OriginalProductId);
            if (orderItem != null)
            {
                orderItem.ProductId = replacement.ReplacementProductId;
            }

            // Update or replace the Sale record
            var sale = _context.Sales
                .FirstOrDefault(s => s.ProductId == replacement.OriginalProductId
                    && s.OrderId == replacement.OrderId);

            if (sale != null)
            {
                sale.ProductId = replacement.ReplacementProductId;
                sale.IsReplacement = true;
            }

            _context.SaveChanges();
            return RedirectToAction("Index");
        }

        [HttpPost]
        public IActionResult Cancel(int id)
        {
            var replacement = _context.Replacements.Find(id);
            if (replacement == null) return NotFound();
            if (replacement.Status != "Pending") return BadRequest("Only pending replacements can be cancelled.");

            replacement.Status = "Cancelled";
            _context.SaveChanges();

            return RedirectToAction("Index");
        }

        public IActionResult GetOrderItems(int orderId)
        {
            var items = _context.OrderItems
                .Include(oi => oi.Product)
                .Where(oi => oi.OrderId == orderId)
                .Select(oi => new
                {
                    oi.ProductId,
                    ProductName = oi.Product != null ? oi.Product.Name : "",
                    oi.Quantity
                })
                .ToList();

            return Json(items);
        }
    }
}
