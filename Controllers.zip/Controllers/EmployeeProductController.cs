﻿using ChocoLync.Data;
using ChocoLync.Filters;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ChocoLync.Controllers
{
    [RoleAuthorize("Employee")]
    public class EmployeeProductController
        : Controller
    {
        private readonly ApplicationDbContext _context;

        public EmployeeProductController(
            ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            var products =
                _context.Products
                .Include(x => x.Category)
                .ToList();

            return View(products);
        }
    }
}