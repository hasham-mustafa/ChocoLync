﻿using ChocoLync.Data;
using ChocoLync.Filters;
using ChocoLync.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ChocoLync.Controllers
{
    public class OrderController : Controller
    {
        private readonly ApplicationDbContext _context;

        public OrderController(ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            var orders = _context.Orders
                .OrderByDescending(x => x.OrderDate)
                .ToList();

            return View(orders);
        }

        public IActionResult Details(int id)
        {
            var order = _context.Orders
                .FirstOrDefault(x => x.Id == id);

            if (order == null) return NotFound();

            var orderItems = _context.OrderItems
                .Include(x => x.Product)
                .Where(x => x.OrderId == id)
                .ToList();

            var sales = _context.Sales
                .Where(s => s.OrderId == id)
                .ToList();

            ViewBag.OrderItems = orderItems;
            ViewBag.Sales = sales;

            return View(order);
        }

        public IActionResult ChangeStatus(int id, string status)
        {
            var order = _context.Orders.FirstOrDefault(x => x.Id == id);
            if (order == null) return NotFound();

            string oldStatus = order.Status;
            order.Status = status;

            var orderItems = _context.OrderItems
                .Include(x => x.Product)
                .Where(x => x.OrderId == id)
                .ToList();

            // PENDING -> COMPLETED: reduce stock, create sales
            if (oldStatus != "Completed" && status == "Completed")
            {
                foreach (var item in orderItems)
                {
                    if (item.Product == null) continue;

                    if (item.Product.StockQuantity < item.Quantity)
                    {
                        TempData["Error"] = $"Insufficient stock for {item.Product.Name}.";
                        return RedirectToAction("Index");
                    }

                    item.Product.StockQuantity -= item.Quantity;

                    decimal profit = 0;
                    if (item.Product.BuyingPrice > 0)
                    {
                        profit = (item.Price - item.Product.BuyingPrice) * item.Quantity;
                    }

                    _context.Sales.Add(new Sale
                    {
                        ProductId = item.ProductId,
                        OrderId = id,
                        Quantity = item.Quantity,
                        QuantitySold = item.Quantity,
                        TotalAmount = item.Price * item.Quantity,
                        Profit = profit,
                        SaleDate = DateTime.Now,
                        EmployeeId = null
                    });
                }
            }

            // COMPLETED -> CANCELLED: restore stock, remove related sales
            if (oldStatus == "Completed" && status == "Cancelled")
            {
                foreach (var item in orderItems)
                {
                    if (item.Product != null)
                    {
                        item.Product.StockQuantity += item.Quantity;
                    }
                }

                var sales = _context.Sales.Where(s => s.OrderId == id).ToList();
                _context.Sales.RemoveRange(sales);
            }

            _context.SaveChanges();
            return RedirectToAction("Index");
        }

        [HttpPost]
        [RoleAuthorize("Owner,Admin")]
        public IActionResult RemoveItem(int orderItemId)
        {
            var orderItem = _context.OrderItems
                .Include(x => x.Product)
                .FirstOrDefault(x => x.Id == orderItemId);

            if (orderItem == null) return NotFound();

            var order = _context.Orders.FirstOrDefault(x => x.Id == orderItem.OrderId);
            if (order == null) return NotFound();

            // Restore stock if order was completed (stock was reduced)
            if (order.Status == "Completed" && orderItem.Product != null)
            {
                orderItem.Product.StockQuantity += orderItem.Quantity;
            }

            // Remove associated sale record
            var sale = _context.Sales
                .FirstOrDefault(s => s.OrderId == orderItem.OrderId && s.ProductId == orderItem.ProductId);
            if (sale != null)
            {
                _context.Sales.Remove(sale);
            }

            // Recalculate order total
            order.TotalAmount -= orderItem.Price * orderItem.Quantity;

            _context.OrderItems.Remove(orderItem);
            _context.SaveChanges();

            // Auto-cancel order if no items remain
            var remaining = _context.OrderItems.Count(oi => oi.OrderId == order.Id);
            if (remaining == 0)
            {
                order.Status = "Cancelled";
                _context.SaveChanges();
                TempData["Success"] = $"Order #{order.Id} auto-cancelled — no items remain.";
                return RedirectToAction("Index");
            }

            TempData["Success"] = $"Item removed from order. Stock restored.";
            return RedirectToAction("Details", new { id = orderItem.OrderId });
        }

        [HttpPost]
        [RoleAuthorize("Owner,Admin")]
        public IActionResult ReturnItem(int orderItemId)
        {
            var orderItem = _context.OrderItems
                .Include(x => x.Product)
                .FirstOrDefault(x => x.Id == orderItemId);

            if (orderItem == null) return NotFound();

            var order = _context.Orders.FirstOrDefault(x => x.Id == orderItem.OrderId);
            if (order == null) return NotFound();

            // Restore stock
            if (orderItem.Product != null)
            {
                orderItem.Product.StockQuantity += orderItem.Quantity;
            }

            // Remove associated sale record
            var sale = _context.Sales
                .FirstOrDefault(s => s.OrderId == orderItem.OrderId && s.ProductId == orderItem.ProductId);
            if (sale != null)
            {
                _context.Sales.Remove(sale);
            }

            // Recalculate order total
            order.TotalAmount -= orderItem.Price * orderItem.Quantity;

            _context.OrderItems.Remove(orderItem);
            _context.SaveChanges();

            // Auto-cancel order if no items remain
            var remaining = _context.OrderItems.Count(oi => oi.OrderId == order.Id);
            if (remaining == 0)
            {
                order.Status = "Cancelled";
                _context.SaveChanges();
                TempData["Success"] = $"Order #{order.Id} auto-cancelled — no items remain.";
                return RedirectToAction("Index");
            }

            TempData["Success"] = $"Item returned. Stock restored and entry removed from all records.";
            return RedirectToAction("Details", new { id = orderItem.OrderId });
        }
    }
}
