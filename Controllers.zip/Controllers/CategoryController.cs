﻿using ChocoLync.Data;
using ChocoLync.Filters;
using ChocoLync.Models;
using Microsoft.AspNetCore.Mvc;

namespace ChocoLync.Controllers
{
    public class CategoryController : Controller
    {
        private readonly ApplicationDbContext _context;

        public CategoryController(ApplicationDbContext context)
        {
            _context = context;
        }
        [RoleAuthorize("Admin")]
        // CATEGORY LIST
        public IActionResult Index()
        {
            var categories = _context.Categories.ToList();

            return View(categories);
        }

        // OPEN CREATE PAGE
        public IActionResult Create()
        {
            return View();
        }

        // SAVE CATEGORY
        [HttpPost]
        public IActionResult Create(Category category)
        {
            if (ModelState.IsValid)
            {
                _context.Categories.Add(category);

                _context.SaveChanges();

                return RedirectToAction("Index");
            }

            return View(category);
        }

        // OPEN EDIT PAGE
        public IActionResult Edit(int id)
        {
            var category = _context.Categories.Find(id);

            if (category == null)
            {
                return NotFound();
            }

            return View(category);
        }

        // UPDATE CATEGORY
        [HttpPost]
        public IActionResult Edit(Category category)
        {
            if (ModelState.IsValid)
            {
                _context.Categories.Update(category);

                _context.SaveChanges();

                return RedirectToAction("Index");
            }

            return View(category);
        }

        // OPEN DELETE PAGE
        public IActionResult Delete(int id)
        {
            var category = _context.Categories.Find(id);

            if (category == null)
            {
                return NotFound();
            }

            return View(category);
        }

        // DELETE CATEGORY
        [HttpPost]
        public IActionResult Delete(Category category)
        {
            var existingCategory = _context.Categories.Find(category.Id);

            if (existingCategory == null)
            {
                return NotFound();
            }

            _context.Categories.Remove(existingCategory);

            _context.SaveChanges();

            return RedirectToAction("Index");
        }
    }
}