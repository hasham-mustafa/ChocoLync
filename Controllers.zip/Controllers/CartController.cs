﻿using ChocoLync.Data;
using ChocoLync.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Text.Json;


namespace ChocoLync.Controllers
{
    public class CartController : Controller
    {
        private readonly ApplicationDbContext _context;

        public CartController(ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult ClearCart()
        {
            HttpContext.Session.Remove("Cart");

            return RedirectToAction("Index");
        }

        public IActionResult AddToCart(int id, int quantity)
        {
            var product =
                _context.Products.Find(id);

            if (product == null)
            {
                return NotFound();
            }

            List<CartItem> cart;

            var sessionCart =
                HttpContext.Session
                .GetString("Cart");

            if (sessionCart != null)
            {
                cart =
                    JsonSerializer.Deserialize
                    <List<CartItem>>(sessionCart);
            }
            else
            {
                cart = new List<CartItem>();
            }

            var existingItem =
                cart.FirstOrDefault(x =>
                    x.ProductId == id);

            if (existingItem != null)
            {
                existingItem.Quantity += quantity;
            }
            else
            {
                cart.Add(new CartItem
                {
                    ProductId = product.Id,
                    ProductName = product.Name,
                    Price = product.Price,
                    Quantity = quantity,
                    ImagePath = product.ImagePath,
                });
            }

            HttpContext.Session.SetString(
                "Cart",
                JsonSerializer.Serialize(cart));

            return RedirectToAction("Index");
        }

        public IActionResult Index()
        {
            var sessionCart =
                HttpContext.Session
                .GetString("Cart");

            List<CartItem> cart =
                new List<CartItem>();

            if (sessionCart != null)
            {
                cart =JsonSerializer.Deserialize<List<CartItem>>(sessionCart);
            }

            return View(cart);
        }

        public IActionResult Remove(int id)
        {
            var sessionCart =
                HttpContext.Session
                .GetString("Cart");

            if (sessionCart != null)
            {
                var cart =
                    JsonSerializer.Deserialize
                    <List<CartItem>>(sessionCart);

                var item =
                    cart.FirstOrDefault(x =>
                        x.ProductId == id);

                if (item != null)
                {
                    cart.Remove(item);
                }

                HttpContext.Session.SetString(
                    "Cart",
                    JsonSerializer.Serialize(cart));
            }

            return RedirectToAction("Index");
        }



        public IActionResult Checkout()
        {
            if (HttpContext.Session.GetString("Username") == null)
            {
                TempData["Message"] =
                    "Please login first to continue checkout.";

                return RedirectToAction(
                    "Login",
                    "Account");
            }

            var sessionCart =
                HttpContext.Session
                .GetString("Cart");

            List<CartItem> cart =
                new List<CartItem>();

            if (sessionCart != null)
            {
                cart =
                    JsonSerializer.Deserialize<List<CartItem>> (sessionCart);
            }

            CheckoutViewModel model =
                new CheckoutViewModel
                {
                    CartItems = cart
                };

            return View(model);
        }


        [HttpPost]
        public IActionResult PlaceOrder(
    CheckoutViewModel model)
        {
            var sessionCart =
                HttpContext.Session
                .GetString("Cart");

            if (sessionCart == null)
            {
                return RedirectToAction("Index");
            }

            var cart =
                JsonSerializer.Deserialize<List<CartItem>>
                (sessionCart);

            if (cart.Count == 0)
            {
                return RedirectToAction("Index");
            }

            // CREATE ORDER

            Order order = new Order
            {
                CustomerName = model.CustomerName,

                CustomerPhone = model.CustomerPhone,

                CustomerAddress = model.CustomerAddress,

                OrderDate = DateTime.Now,

                Status = "Pending",

                TotalAmount =
                    cart.Sum(x =>
                        x.Price * x.Quantity)
            };

            _context.Orders.Add(order);

            _context.SaveChanges();

            // SAVE ORDER ITEMS + SALES

            foreach (var item in cart)
            {
                // ORDER ITEM

                OrderItem orderItem =
                    new OrderItem
                    {
                        OrderId = order.Id,

                        ProductId = item.ProductId,

                        Quantity = item.Quantity,

                        Price = item.Price
                    };

                _context.OrderItems.Add(orderItem);

                


                

               
            }

            // FINAL SAVE

            _context.SaveChanges();

            // CLEAR CART

            HttpContext.Session.Remove("Cart");

            return RedirectToAction(
                "Invoice",
                new { id = order.Id });
        }

        public IActionResult Invoice(int id)
        {
            var order =
                _context.Orders
                .Include(x => x.OrderItems)
                .ThenInclude(x => x.Product)
                .FirstOrDefault(x => x.Id == id);

            return View(order);
        }
    }
}