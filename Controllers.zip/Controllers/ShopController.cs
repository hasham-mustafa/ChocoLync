﻿using ChocoLync.Data;
using Microsoft.AspNetCore.Mvc;

namespace ChocoLync.Controllers
{
    public class ShopController : Controller
    {
        private readonly ApplicationDbContext _context;

        public ShopController(ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            var products = _context.Products.ToList();

            return View(products);
        }
    }
}