﻿using ChocoLync.Data;
using ChocoLync.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using ChocoLync.Filters;

namespace ChocoLync.Controllers
{
    public class EmployeeController : Controller
    {
        private readonly ApplicationDbContext _context;

        public EmployeeController(ApplicationDbContext context)
        {
            _context = context;
        }


        [RoleAuthorize("Employee")]
        public IActionResult Profile()
        {
            var username =
                HttpContext.Session
                .GetString("Username");

            var user =
                _context.Users
                .Include(x => x.Employee)
                    .ThenInclude(x => x.Department)
                .FirstOrDefault(x =>
                    x.Username == username);

            if (user == null || user.Employee == null)
            {
                return NotFound();
            }

            return View(user.Employee);
        }

        [HttpGet]
        [RoleAuthorize("Employee")]
        public IActionResult EditProfile()
        {
            var username =
                HttpContext.Session
                .GetString("Username");

            var user =
                _context.Users
                .Include(x => x.Employee)
                .FirstOrDefault(x =>
                    x.Username == username);

            if (user == null || user.Employee == null)
            {
                return NotFound();
            }

            return View(user.Employee);
        }


        [HttpPost]
        [RoleAuthorize("Employee")]
        public IActionResult EditProfile(
    Employee employee,
    IFormFile? ImageFile)
        {
            var existingEmployee =
                _context.Employees
                .FirstOrDefault(x =>
                    x.Id == employee.Id);

            if (existingEmployee == null)
            {
                return NotFound();
            }

            existingEmployee.Name =
                employee.Name;

            existingEmployee.Phone =
                employee.Phone;

            existingEmployee.Email =
                employee.Email;

            existingEmployee.Country =
                employee.Country;

            existingEmployee.CNIC =
                employee.CNIC;

            existingEmployee.DateOfBirth =
                employee.DateOfBirth;

            existingEmployee.Education =
                employee.Education;

            existingEmployee.Address =
                employee.Address;

            if (ImageFile != null)
            {
                string folder =
                    Path.Combine(
                        Directory.GetCurrentDirectory(),
                        "wwwroot/uploads");

                string fileName =
                    Guid.NewGuid().ToString()
                    + Path.GetExtension(ImageFile.FileName);

                string filePath =
                    Path.Combine(folder, fileName);

                using (var stream =
                    new FileStream(filePath,
                    FileMode.Create))
                {
                    ImageFile.CopyTo(stream);
                }

                existingEmployee.ProfileImage =
                    "uploads/" + fileName;
            }

            _context.SaveChanges();

            HttpContext.Session.SetString(
                "ProfileImage",
                existingEmployee.ProfileImage ?? "");

            return RedirectToAction("Profile");
        }

        [RoleAuthorize("Owner,Admin")]
        // EMPLOYEE LIST
        public IActionResult Index()
        {
            var employees = _context.Employees
                .Include(e => e.Department)
                .ToList();

            return View(employees);
        }
        [RoleAuthorize("Admin")]
        // OPEN CREATE PAGE
        public IActionResult Create()
        {
            ViewBag.DepartmentList =
                _context.Departments.ToList();

            return View();
        }
        [RoleAuthorize("Admin")]
        // SAVE EMPLOYEE
        [HttpPost]
        public IActionResult Create(Employee employee)
        {
            ViewBag.DepartmentList =
                _context.Departments.ToList();

            if (ModelState.IsValid)
            {
                _context.Employees.Add(employee);

                _context.SaveChanges();

                return RedirectToAction("Index");
            }

            return View(employee);
        }
        [RoleAuthorize("Admin")]
        // OPEN EDIT PAGE
        public IActionResult Edit(int id)
        {
            var employee =
                _context.Employees.Find(id);

            if (employee == null)
            {
                return NotFound();
            }

            ViewBag.DepartmentList =
                _context.Departments.ToList();

            return View(employee);
        }
        [RoleAuthorize("Admin")]
        // UPDATE EMPLOYEE
        [HttpPost]
        public IActionResult Edit(Employee employee)
        {
            ViewBag.DepartmentList =
                _context.Departments.ToList();

            if (ModelState.IsValid)
            {
                _context.Employees.Update(employee);

                _context.SaveChanges();

                return RedirectToAction("Index");
            }

            return View(employee);
        }
        [RoleAuthorize("Admin")]
        // OPEN DELETE PAGE
        public IActionResult Delete(int id)
        {
            var employee =
                _context.Employees
                .Include(e => e.Department)
                .FirstOrDefault(e => e.Id == id);

            if (employee == null)
            {
                return NotFound();
            }

            return View(employee);
        }
        [RoleAuthorize("Admin")]
        // DELETE EMPLOYEE
        [HttpPost]
        public IActionResult Delete(Employee employee)
        {
            var existingEmployee =
                _context.Employees.Find(employee.Id);

            if (existingEmployee == null)
            {
                return NotFound();
            }

            _context.Employees.Remove(existingEmployee);

            _context.SaveChanges();

            return RedirectToAction("Index");
        }
    }
}