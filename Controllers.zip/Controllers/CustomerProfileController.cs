﻿using ChocoLync.Data;
using ChocoLync.Filters;
using ChocoLync.Models;
using Microsoft.AspNetCore.Mvc;

namespace ChocoLync.Controllers
{
    public class CustomerProfileController : Controller
    {
        private readonly ApplicationDbContext _context;

        public CustomerProfileController(
            ApplicationDbContext context)
        {
            _context = context;
        }

        [RoleAuthorize("Customer")]
        public IActionResult Profile()
        {
            var username =
               HttpContext.Session
               .GetString("CustomerUsername");

            var customer =
                _context.Customers
                .FirstOrDefault(x =>
                    x.Username == username);

            if (customer == null)
            {
                return RedirectToAction(
                    "Login",
                    "Account");
            }

            return View(customer);
        }

        [HttpGet]
        [RoleAuthorize("Customer")]
        public IActionResult EditProfile()
        {
            var username =
                HttpContext.Session
                .GetString("CustomerUsername");

            var customer =
                _context.Customers
                .FirstOrDefault(x =>
                    x.Username == username);

            if (customer == null)
            {
                return RedirectToAction(
                    "Login",
                    "Account");
            }

            return View(customer);
        }

        [HttpPost]
        [RoleAuthorize("Customer")]
        public IActionResult EditProfile(
            Customer customer,
            IFormFile? ImageFile)
        {
            var existingCustomer =
                _context.Customers
                .FirstOrDefault(x =>
                    x.Id == customer.Id);

            if (existingCustomer == null)
            {
                return NotFound();
            }

            existingCustomer.Name =
                customer.Name;

            existingCustomer.Email =
                customer.Email;

            existingCustomer.Phone =
                customer.Phone;

            existingCustomer.Country =
                customer.Country;

            existingCustomer.CNIC =
                customer.CNIC;

            existingCustomer.DateOfBirth =
                customer.DateOfBirth;

            existingCustomer.Address =
                customer.Address;

            if (ImageFile != null)
            {
                string folder =
                    Path.Combine(
                        Directory.GetCurrentDirectory(),
                        "wwwroot/uploads");

                string fileName =
                    Guid.NewGuid().ToString()
                    + Path.GetExtension(ImageFile.FileName);

                string filePath =
                    Path.Combine(folder, fileName);

                using (var stream =
                    new FileStream(filePath,
                    FileMode.Create))
                {
                    ImageFile.CopyTo(stream);
                }

                existingCustomer.ProfileImage =
                    "uploads/" + fileName;
            }

            _context.SaveChanges();

            HttpContext.Session.SetString(
                "ProfileImage",
                existingCustomer.ProfileImage ?? "");

            return RedirectToAction("Profile");
        }
    }
}
